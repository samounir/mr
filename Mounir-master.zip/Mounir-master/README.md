# Pinkoob
Pinkoob is a RTL WordPress theme inspired by Pinterest.com and Unsplash.com.

# Requirements
PHP 5.6+ (7.2 is recommended)

# Demo
visti Pinkoob.com

# Persian Support
visit Skilledup.ir