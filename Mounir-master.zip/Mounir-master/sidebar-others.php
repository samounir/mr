<div class="sidebar">
	<?php if (!dynamic_sidebar('sidebar-others') && current_user_can('administrator')) : ?>
		<div class="sidebar-wrapper">
			<div class="sidebar-inner">
				فقط المشرف يرى هذا النص.
				<a href="<?php echo admin_url('/widgets.php'); ?>">أضف بعض الأدوات</a> إلى الشريط الجانبي لاستبدال هذا النص.
			</div>
		</div>
	<?php endif ?>
</div>