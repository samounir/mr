<?php
	get_template_part('color');
?>